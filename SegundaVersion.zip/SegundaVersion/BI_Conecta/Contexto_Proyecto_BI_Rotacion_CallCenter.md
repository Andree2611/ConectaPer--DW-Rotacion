# Documento de contexto del proyecto: Data Warehouse de rotación de personal de un Call Center

> **Propósito de este documento:** permitir que otra IA comprenda el proyecto existente, su arquitectura, el proceso ETL y el objetivo de construir una solución de Business Intelligence (BI) sobre el Data Warehouse ya desarrollado.
>
> **Fuente analizada:** `PrimeraVersion.zip`, entregado por el equipo. Se revisaron la estructura del ZIP, los paquetes SSIS (`.dtsx`), el proyecto SSIS (`.dtproj`), los administradores de conexión y los elementos disponibles. El ZIP también contiene dos respaldos SQL Server (`.bak`), pero no se restauraron ni se inspeccionaron sus datos internamente en este análisis. Por ello, las descripciones del esquema se limitan a lo que se puede demostrar mediante los paquetes y metadatos revisados.

---

## 1. Contexto general y propósito del proyecto

El proyecto trabaja con información de recursos humanos de un Call Center y tiene como eje analítico la **rotación del personal**. El Data Warehouse integra eventos de ingreso y salida de empleados, junto con atributos que permiten analizarlos por tiempo, empleado, cargo, sede, turno/horario y motivo de salida.

El equipo ya avanzó la construcción del Data Warehouse. La finalidad de la siguiente etapa es desarrollar una solución de **Business Intelligence** que convierta los datos integrados en indicadores, análisis, visualizaciones y herramientas de apoyo a la toma de decisiones.

### Preguntas de negocio que debe responder el BI

1. **¿Cuál es la tasa de rotación?**
   - Cuántos ingresos de personal se registraron.
   - Cuántas salidas de personal se registraron.
   - Cómo evoluciona la rotación en el tiempo.
   - La tasa porcentual debe definirse con una fórmula y una población de referencia explícitas; no debe confundirse el número de altas/bajas con la tasa porcentual.

2. **¿Cuál es el turno con más rotación?**
   - Comparar ingresos y salidas por turno u horario.
   - Identificar el turno con mayor cantidad de bajas y, si corresponde, la mayor tasa de rotación.
   - No confundir el turno (`NombreTurno`) con el horario (`NombreHorario`): el modelo ETL relaciona ambos mediante `IdHorario`.

3. **¿Cuál es el nivel de instrucción del personal?**
   - Mostrar la distribución del personal por nivel educativo/instrucción.
   - Analizarla, si los datos lo permiten, por estado laboral, turno, cargo y eventos de salida.
   - **Punto pendiente de verificar:** el SELECT de extracción de empleados revisado no incluye un campo de nivel de instrucción. No se debe afirmar que este indicador está disponible en el DW hasta revisar el esquema físico y el respaldo de la base OLTP/DW.

4. **¿Cuál es el costo por rotación del personal?**
   - Analizar el costo asociado a las desvinculaciones.
   - El proceso de extracción de eventos incorpora `CostoDesvinculacion`, obtenido mediante la suma de registros de `CostoDesvinculacion.Monto` para cada desvinculación.
   - El hecho también contiene/revisa `CostoTotalRotacion`, pero el cálculo y composición de este campo deben verificarse en el esquema y en los objetos SQL de la base restaurada.
   - No asumir que el costo de desvinculación equivale a todo el costo de rotación: pueden existir costos adicionales de reclutamiento, selección, capacitación, inducción, productividad perdida, etc. Solo deben incorporarse si existen datos y reglas aprobadas.

5. **¿Cuál es el costo de retención?**
   - Determinar cuánto cuesta mantener al personal y/o ejecutar acciones para evitar su salida.
   - **Punto pendiente de verificar:** en los paquetes revisados no se identificó una extracción explícita de costos de retención ni una dimensión/hecho dedicado a intervenciones de retención. El modelo podría no contener todavía esa información.
   - Antes de calcular este KPI, el negocio debe definir qué considera costo de retención (bonos, incentivos, beneficios, capacitación, aumentos, programas de bienestar, etc.), el periodo y la unidad de análisis.

---

## 2. Contenido del ZIP y componentes identificados

El archivo contiene, entre otros, estos elementos:

```text
PrimeraVersion/
├── BD_CallCenter_Rotacion.bak
├── DWT4_Rotacion.bak
└── DWT4CallCenter/
    ├── DWT4CallCenter.slnx
    └── DWT4CallCenter/
        ├── DWT4CallCenter.dtproj
        ├── DWT4CallCenter.database
        ├── ETL_RotacionDW.dtsx
        ├── DimTiempo.dtsx
        ├── DimEmpleado.dtsx
        ├── DimCargo.dtsx
        ├── DimSede.dtsx
        ├── DimTurno.dtsx
        ├── DimMotivoSalida.dtsx
        ├── HechoRotacion.dtsx
        ├── ReconciliacionDatos.dtsx
        ├── *.conmgr
        ├── bin/Development/DWT4CallCenter.ispac
        └── obj/Development/...
```

### Interpretación de los archivos

- `BD_CallCenter_Rotacion.bak`: respaldo de una base SQL Server que, por el nombre y las conexiones, corresponde a la base de origen/transaccional.
- `DWT4_Rotacion.bak`: respaldo de la base de datos del Data Warehouse.
- `DWT4CallCenter.dtproj`: proyecto de Integration Services que agrupa los paquetes ETL.
- `*.dtsx`: paquetes SSIS que implementan extracciones, cargas, validaciones y reconciliaciones.
- `*.conmgr`: administradores de conexión a las bases de origen y destino.
- `DWT4CallCenter.ispac`: artefacto de despliegue del proyecto SSIS.
- `obj/` y `.vs/`: archivos generados por Visual Studio/SSIS; no constituyen por sí mismos lógica de negocio adicional.

El proyecto está configurado como proyecto SSIS (`DeploymentModel = Project`). En los administradores de conexión inspeccionados aparecen estas bases:

- Origen: `BD_CallCenter_Rotacion`
- Destino: `DWT4_Rotacion`

La cadena de conexión incluida hace referencia a una instancia local llamada `LAPTOP-AR02VJ9A\SQLSSERVER` y utiliza autenticación integrada de Windows. Es una configuración del entorno del desarrollador, no una dirección que deba asumirse válida en otro equipo.

---

## 3. Arquitectura lógica observada

La arquitectura que se puede reconstruir a partir de los paquetes es:

```text
Base operacional / OLTP
BD_CallCenter_Rotacion
        |
        | Consultas de extracción en SSIS
        v
Área de staging
STG
        |
        | Validación, transformación y carga dimensional
        v
Esquema dimensional
DW
  ├── DimTiempo
  ├── DimEmpleado
  ├── DimCargo
  ├── DimSede
  ├── DimTurno
  ├── DimMotivoSalida
  └── HechoRotacion
        |
        | Consultas analíticas / modelo semántico
        v
Solución de Business Intelligence
Indicadores, gráficos, filtros, reportes y paneles
```

### Función de cada capa

**OLTP / origen**
- Contiene la información operacional del Call Center.
- Los paquetes consultan tablas como `Empleado`, `Persona`, `Contrato`, `Desvinculacion`, `Cargo`, `Sede`, `Turno`, `Horario`, historiales de asignación y costos de desvinculación.

**STG / staging**
- Es el área temporal de preparación.
- Los datos extraídos se depositan en tablas del esquema `STG`.
- El paquete principal limpia las tablas de staging antes de volver a cargarlas.
- Staging permite separar la extracción del origen de la carga dimensional.

**DW / Data Warehouse**
- Conserva dimensiones y hechos preparados para análisis.
- Usa claves sustitutas (`SK`) en dimensiones y claves de origen para relacionar los registros con el sistema operacional.
- Algunas dimensiones implementan control de cambios históricos mediante vigencia y `EsActual`, patrón compatible con Slowly Changing Dimension tipo 2 (SCD tipo 2).

**BI / capa de consumo**
- Todavía es la etapa que se busca construir.
- Debe utilizar el DW como fuente, no reconstruir la lógica operacional desde cero ni consultar directamente la base OLTP para cada visualización, salvo que exista una razón documentada.

---

## 4. Proceso ETL identificado

El paquete principal es `ETL_RotacionDW.dtsx`.

### 4.1 Extracción y carga de staging

Se identificaron flujos de datos para:

| Flujo SSIS | Origen consultado | Destino de staging |
|---|---|---|
| `Cargo` | `dbo.Cargo` | `STG.Cargo` |
| `Empleados` | `dbo.Empleado`, `dbo.Persona`, `dbo.Contrato`, `dbo.Desvinculacion` | `STG.Empleado` |
| `MotivoSalida` | `dbo.MotivoSalida` | `STG.MotivoSalida` |
| `Rotacion` | `dbo.Contrato`, `dbo.Desvinculacion`, historiales de sede/turno, `dbo.Horario`, `dbo.CostoDesvinculacion` | `STG.Rotacion` |
| `Sede` | `dbo.Sede` | `STG.Sede` |
| `Turno` | `dbo.Turno`, `dbo.Horario` | `STG.Turno` |

Antes de cargar, el paquete ejecuta una limpieza de staging mediante `TRUNCATE TABLE` sobre:

- `STG.Empleado`
- `STG.Cargo`
- `STG.Sede`
- `STG.Turno`
- `STG.MotivoSalida`
- `STG.Rotacion`

Esto indica que el proceso implementado vuelve a cargar el conjunto de staging desde el origen en cada ejecución. No debe confundirse esta limpieza de staging con una eliminación total del histórico del DW.

### 4.2 Extracción de empleados

El SELECT revisado combina:

- `Empleado` (`E`)
- `Persona` (`P`)
- El contrato más reciente del empleado, obtenido con `OUTER APPLY` y `TOP 1`, ordenado por `FechaInicio DESC, IdContrato DESC`.
- `Desvinculacion` (`D`)

Campos extraídos, entre otros:

- Identificadores de empleado y persona de origen.
- Código de empleado.
- Tipo y número de documento.
- Nombres y apellidos.
- Nombre completo calculado.
- Fecha de nacimiento.
- Sexo.
- Correo y teléfono.
- Identificadores del contrato y cargo.
- Tipo de contrato.
- Fecha de inicio del contrato.
- Fecha fin prevista.
- Salario mensual.
- Estado laboral calculado como `Activo` o `Cesado`, según la presencia de una desvinculación asociada al contrato seleccionado.

**Limitación importante:** este SELECT no muestra un campo de nivel de instrucción/educación. Hay que verificar si existe en otra tabla de la base de origen y si fue omitido de la extracción, o si sencillamente no existe en la versión actual del modelo.

### 4.3 Construcción de eventos de rotación

La extracción de `STG.Rotacion` combina dos conjuntos mediante `UNION ALL`:

**Evento de alta (`ALTA`)**
- Se genera por cada contrato.
- Identificador de evento: `ALTA_` + `IdContrato`.
- Fecha del evento: `Contrato.FechaInicio`.
- `CantidadAltas = 1`.
- `CantidadBajas = 0`.
- `AntiguedadDias = 0`.
- `CostoDesvinculacion = 0`.
- Recupera cargo, empleado, sede, horario y turno asociados a la fecha de inicio del contrato.
- El motivo de salida es NULL.

**Evento de baja (`BAJA`)**
- Se genera por cada registro de desvinculación.
- Identificador de evento: `BAJA_` + `IdDesvinculacion`.
- Fecha del evento: `Desvinculacion.FechaSalida`.
- `CantidadAltas = 0`.
- `CantidadBajas = 1`.
- Calcula antigüedad con `DATEDIFF(DAY, FechaInicioContrato, FechaSalida)`.
- Obtiene el motivo de salida.
- Calcula el costo sumando `Monto` en `CostoDesvinculacion` para la desvinculación correspondiente; si no hay importe, utiliza cero.
- Recupera sede y horario/turno vigentes a la fecha de salida mediante historiales de asignación.

La selección de sede y turno usa `OUTER APPLY` para buscar el registro de historial cuya vigencia contiene la fecha del evento (`FechaInicio <= fecha del evento` y `FechaFin IS NULL OR FechaFin >= fecha del evento`), tomando el registro más reciente por `FechaInicio`.

**Consecuencia analítica:** la tabla de hechos representa eventos, no solamente una fila por empleado. Un mismo empleado puede tener varias altas/bajas a lo largo de su historial si el origen contiene varios contratos y desvinculaciones. Por ello, al contar empleados únicos debe usarse una lógica distinta a sumar eventos.

### 4.4 Paquetes de dimensiones

Se encontraron paquetes independientes:

- `DimTiempo.dtsx`
- `DimEmpleado.dtsx`
- `DimCargo.dtsx`
- `DimSede.dtsx`
- `DimTurno.dtsx`
- `DimMotivoSalida.dtsx`

En general, los paquetes dimensionales contienen tareas de carga y validación de staging/dimensión. Los nombres identificados incluyen:

- `Cargar_DimEmpleado`, `Validar_DimEmpleado`, `Validar_STG_Empleado`
- `Cargar_DimCargo`, `Validar_DimCargo`, `Validar_STG_Cargo`
- `Cargar_DimSede`, `Validar_DimSede`, `Validar_STG_Sede`
- `Cargar_DimTurno`, `Validar_DimTurno`, `Validar_STG_Turno`
- `Cargar_DimMotivoSalida`, `Validar_DimMotivoSalida`, `Validar_STG_MotivoSalida`
- `Obtener_Rango_Fechas`, `Cargar_DimTiempo`

La dimensión de turno tiene una particularidad: la extracción combina `Turno` con `Horario`, y la clave de negocio usada para la dimensión es `IdHorarioOrigen`. Esto permite distinguir horarios asociados a un mismo turno.

### 4.5 Carga de la tabla de hechos

El paquete `HechoRotacion.dtsx` incluye tareas para:

- Validar prerrequisitos.
- Limpiar el hecho.
- Cargar el hecho.
- Reconciliar la carga.
- Validar el resultado.

El SQL de carga revisado transforma `STG.Rotacion` y lo inserta/actualiza en `DW.HechoRotacion` mediante `MERGE`, usando `IdEventoOrigen` como identificador del evento.

La carga relaciona los eventos con:

- `DW.DimTiempo`
- `DW.DimEmpleado`
- `DW.DimCargo`
- `DW.DimSede`
- `DW.DimTurno`
- `DW.DimMotivoSalida`

La búsqueda de dimensiones utiliza las claves de origen y, para las dimensiones históricas, filtra por `EsActual = 1`. En sede y turno se admite ausencia de correspondencia mediante clave desconocida `-1`; las validaciones previas permiten NULL en ciertos atributos opcionales, pero el hecho y sus controles deben revisarse para asegurar que el resultado final sea coherente.

El hecho carga o actualiza, entre otros, estos campos:

- `IdEventoOrigen`
- `TipoEvento`
- `IdFecha`
- `IdEmpleadoSK`
- `IdCargoSK`
- `IdSedeSK`
- `IdTurnoSK`
- `IdMotivoSalidaSK`
- `IdContratoOrigen`
- `CantidadAltas`
- `CantidadBajas`
- `AntiguedadDias`
- `SalarioMensual`
- `CostoDesvinculacion`
- `FechaCargaDW`

El SQL de carga obtiene `AntiguedadDias` desde el staging y, si falta, la calcula con la fecha de inicio del contrato en la dimensión empleado y la fecha del evento. Para salario usa, en orden, `STG.Rotacion.SalarioMensual`, `DimEmpleado.SalarioMensual`, `DimCargo.SalarioBaseReferencial` y finalmente cero.

**Advertencia de diseño:** el paquete contiene una tarea llamada `Limpiar_HechoRotacion` cuyo SQL es `TRUNCATE TABLE DW.HechoRotacion`, mientras que la carga usa `MERGE`. La ejecución completa del flujo y el orden de las tareas determinan si se conserva histórico o se reconstruye el hecho en cada corrida. Antes de implementar cargas incrementales o comparar snapshots, se debe confirmar el orden de precedencia y la estrategia efectiva.

### 4.6 Validaciones y reconciliación del hecho

El SQL revisado realiza controles como:

- El hecho no debe estar vacío.
- El número de filas de `STG.Rotacion` y `DW.HechoRotacion` debe coincidir.
- No debe haber empleados ni cargos desconocidos (`SK = -1` o NULL).
- Costos, salarios y antigüedad no deben ser negativos.
- Cada `IdEventoOrigen` debe ser único.
- Cada evento debe representar exactamente un alta o una baja.
- Deben reconciliarse cantidades de altas y bajas entre staging y DW.
- Deben coincidir los eventos distintos.
- Debe coincidir el total de `CostoDesvinculacion`, con tolerancia de 0.01.
- Debe coincidir la suma de `AntiguedadDias`.

El paquete `ReconciliacionDatos.dtsx` contiene controles de calidad identificados por nombre:

- `Iniciar_Control_Calidad`
- `Control_Estructural_DW`
- `Control_Dimensional`
- `Control_Medidas`
- `Control_CostoHistorico`
- `Control_SSD`
- `Reconciliacion_OLT_STG_DW`
- `Finalizar_Control_Calidad`

Se identificó una llamada explícita a `CTL.SP_IniciarControlCalidad`. Los detalles completos de los procedimientos almacenados llamados por todas las tareas no pudieron reconstruirse solamente con la lectura de los paquetes; deben inspeccionarse en la base restaurada.

---

## 5. Modelo dimensional y lectura analítica

El modelo observado tiene una tabla de hechos central llamada `DW.HechoRotacion` y las dimensiones indicadas a continuación.

| Objeto | Papel analítico esperado | Atributos identificados en extracción/carga |
|---|---|---|
| `DW.HechoRotacion` | Registra eventos de alta y baja | TipoEvento, fecha, cantidades, antigüedad, salario, costo de desvinculación y claves de dimensiones |
| `DW.DimTiempo` | Permite analizar por fecha y periodos | `IdFecha`, `Fecha`; el paquete obtiene un rango de fechas |
| `DW.DimEmpleado` | Describe al empleado/contrato | Código, nombres, datos personales, fecha de nacimiento, sexo, correo, teléfono, contrato, salario y estado laboral |
| `DW.DimCargo` | Describe el cargo | NombreCargo, SalarioBaseReferencial, Activo |
| `DW.DimSede` | Describe la sede | NombreSede, Ciudad, Dirección, FechaApertura, Activo |
| `DW.DimTurno` | Describe turno y horario | NombreTurno, DescripcionTurno, NombreHorario, HoraInicio, HoraFin, HorasSemanales, Activo |
| `DW.DimMotivoSalida` | Describe la razón de salida | NombreMotivo, TipoSalida, EsEvitable, Activo |

Los nombres anteriores se apoyan en los campos observados en los SELECT de extracción y en el SQL de carga. Para conocer el esquema físico completo (tipos, nulabilidad, restricciones, índices y todas las columnas), hay que consultar la base `DWT4_Rotacion` restaurada.

### 5.1 Grano de la tabla de hechos

El grano lógico que expresa el ETL es:

> **Una fila por evento de alta o baja identificado por `IdEventoOrigen`.**

Los identificadores se construyen como `ALTA_<IdContrato>` y `BAJA_<IdDesvinculacion>`. Esto permite distinguir dos tipos de eventos en una misma tabla de hechos.

No se debe asumir que el grano es “una fila por empleado”, “una fila por mes” ni “una fila por contrato” sin matices.

### 5.2 Medidas y campos numéricos relevantes

- `CantidadAltas`: indicador aditivo de altas; en el ETL toma 1 para ALTA y 0 para BAJA.
- `CantidadBajas`: indicador aditivo de bajas; en el ETL toma 1 para BAJA y 0 para ALTA.
- `AntiguedadDias`: días transcurridos entre inicio del contrato y evento de salida; para alta se inicializa en cero.
- `SalarioMensual`: salario de referencia asociado al evento.
- `CostoDesvinculacion`: suma de importes asociados a una desvinculación; cero para altas.
- `CostoTotalRotacion`: aparece en una validación del hecho, pero su definición exacta y su proceso de cálculo no quedan demostrados por el SQL de carga recuperado.

**Precaución:** `SalarioMensual` es un atributo numérico asociado al evento, no necesariamente un costo incurrido por la empresa. Sumar salarios de todas las filas de la tabla de hechos podría duplicar valores por empleado/contrato y no debe hacerse sin una definición de negocio.

---

## 6. Cómo traducir las cinco preguntas a indicadores BI

Esta sección plantea una guía de análisis. No afirma que los KPI ya estén implementados ni que todos los datos estén disponibles.

### KPI 1. Tasa de rotación, ingresos y salidas

**Conteo de ingresos**
- Sumar `CantidadAltas`.
- Filtrar por fecha, sede, cargo, turno u otras dimensiones.

**Conteo de salidas**
- Sumar `CantidadBajas`.
- Filtrar por fecha, sede, cargo, turno, motivo de salida, etc.

**Balance neto de movimientos**
- `Altas - Bajas`.
- Es un balance de movimientos, no una tasa de rotación.

**Tasa porcentual**
- Requiere acordar la fórmula y disponer del promedio de personal del periodo.
- Una fórmula habitual en gestión de RR. HH. es:

  `Tasa de rotación (%) = (Número de bajas del periodo / Promedio de trabajadores del periodo) × 100`

- Otra convención puede considerar el promedio entre altas y bajas en el numerador. No se debe escoger una fórmula sin validar el criterio solicitado por el curso/organización.
- Para obtener el promedio de trabajadores se necesitan snapshots de dotación o una forma confiable de reconstruir cuántos empleados estaban activos en cada fecha. La tabla de eventos por sí sola puede no bastar, especialmente si faltan altas históricas anteriores al periodo analizado.

**Visualizaciones recomendadas**
- Tarjetas: total de altas, total de bajas, tasa de rotación.
- Serie temporal por mes: altas y bajas.
- Gráfico de balance neto.
- Filtros de periodo, sede, cargo y turno.

### KPI 2. Turno con más rotación

- Agrupar por `DimTurno.NombreTurno` y/o `DimTurno.NombreHorario`.
- Sumar `CantidadBajas` para conocer el volumen de salidas.
- Mostrar también `CantidadAltas` y el balance.
- Si se quiere afirmar cuál tiene la mayor **tasa**, se necesita el promedio de trabajadores asignados a cada turno durante el periodo. El turno con más bajas absolutas no necesariamente es el de mayor tasa.

**Visualizaciones recomendadas**
- Barras horizontales de bajas por turno/horario.
- Matriz por turno con altas, bajas, balance y tasa (si puede calcularse).
- Desglose por sede y periodo.

**Advertencia:** el ETL recupera el horario vigente a la fecha del evento a través del historial de asignación. Esto es importante: analizar el turno actual del empleado podría atribuir incorrectamente una salida histórica a un turno al que fue trasladado después.

### KPI 3. Nivel de instrucción del personal

- Primero verificar la existencia del atributo en la base OLTP y en el DW.
- El SELECT de `STG.Empleado` que se encontró no incluye nivel educativo.
- Si existe en `Persona` u otra tabla, habría que evaluar su extracción y carga a `DimEmpleado` o a una dimensión relacionada.
- Si no existe, se necesita incorporar la fuente mediante una modificación del modelo/ETL o reconocer que el KPI no puede calcularse con los datos actuales.

**No inventar categorías educativas ni inferirlas a partir del cargo, salario, edad o experiencia.**

**Visualizaciones recomendadas, solo si el dato existe:**
- Distribución porcentual por nivel de instrucción.
- Nivel de instrucción por estado laboral.
- Nivel de instrucción por turno/cargo.
- Comparación de salidas por nivel educativo, cuidando usar tasas y no solo cantidades.

### KPI 4. Costo por rotación del personal

La evidencia directa disponible es `CostoDesvinculacion`, que se extrae sumando `Monto` de `dbo.CostoDesvinculacion` por `IdDesvinculacion`.

**Medida mínima respaldada por el ETL**
- Suma de `CostoDesvinculacion` para eventos `BAJA`.
- Costo de desvinculación promedio por baja: suma de costos / número de bajas, definiendo qué hacer con bajas cuyo costo es cero o NULL.

**Puntos que deben verificarse**
- Qué conceptos componen `CostoDesvinculacion`.
- Si `CostoTotalRotacion` incluye costos distintos del costo de desvinculación.
- Si existen costos de reclutamiento, selección, contratación, capacitación inicial, uniformes/equipos, inducción o productividad perdida.
- Si los costos están en moneda homogénea y si se requiere conversión/ajuste por inflación.
- Si los importes son costos reales, estimaciones o valores referenciales.

No sumar automáticamente `CostoDesvinculacion` y `CostoTotalRotacion`: primero hay que determinar si uno incluye al otro para evitar doble contabilización.

### KPI 5. Costo de retención

En lo revisado no se encontró un flujo de extracción de costos de retención. La base OLTP puede tener tablas adicionales no consultadas por los paquetes, por lo que la ausencia no se puede declarar definitiva sin inspeccionar los respaldos restaurados.

**Definición de negocio que debe acordarse**
- ¿Se considera retención el costo de bonos, incentivos y aumentos?
- ¿Se incluyen beneficios, programas de bienestar, capacitación o planes de carrera?
- ¿Se mide por empleado, evento, programa, sede, turno o periodo?
- ¿Se quiere medir el costo total de retener o el costo por empleado retenido?
- ¿Cómo se define que una persona fue retenida? Por ejemplo, permanecer 3, 6 o 12 meses después de una intervención.

**Datos potencialmente necesarios**
- Identificador de empleado.
- Tipo de acción/programa de retención.
- Fecha de ejecución.
- Importe/costo.
- Periodo de vigencia.
- Sede/turno/cargo en el momento de la intervención.
- Resultado o ventana de permanencia posterior.

Si no existen esos datos, el KPI requiere ampliar la fuente operacional o incorporar un proceso de registro. No es válido calcular un costo de retención a partir del salario mensual sin una definición aprobada.

---

## 7. Riesgos, vacíos y verificaciones necesarias antes de diseñar el BI

1. **Nivel de instrucción:** no aparece en el SELECT de empleados inspeccionado. Verificar tablas/campos de origen y destino.
2. **Costo de retención:** no se identificó extracción explícita. Buscar tablas de incentivos, beneficios, capacitación, bonos u otras inversiones en personal.
3. **Definición de `CostoTotalRotacion`:** aparece en validaciones, pero su cálculo no se ve en el SQL de carga recuperado.
4. **Tasa de rotación:** requiere promedio de dotación por periodo; los eventos de altas y bajas no garantizan por sí solos ese denominador.
5. **Histórico de dotación:** el SELECT de empleados toma el contrato más reciente por empleado. Esto describe el contrato más reciente, no necesariamente todo el historial de atributos del empleado. Los eventos sí se generan desde los contratos y desvinculaciones.
6. **Dimensión empleado e historial:** confirmar qué atributos son SCD2 y si las claves históricas se resuelven correctamente. El hecho actualmente enlaza con `DimEmpleado` usando `EsActual = 1`; esto puede asociar eventos pasados a la versión actual del empleado y no a la versión válida en la fecha del evento.
7. **Carga del hecho:** existe una tarea de `TRUNCATE` y una carga `MERGE`. Revisar el orden de ejecución y determinar si el hecho queda reconstruido o si se conserva incrementalmente.
8. **Turno vs. horario:** la clave de relación de la dimensión es `IdHorarioOrigen`. Definir claramente el nivel de análisis en el dashboard.
9. **Fechas:** el hecho relaciona `FechaEvento` con `DimTiempo.Fecha`. Verificar tipos de datos y si hay horas/minutos que puedan impedir coincidencias exactas.
10. **Backups:** el ZIP contiene `BD_CallCenter_Rotacion.bak` y `DWT4_Rotacion.bak`. Para confirmar el esquema completo, procedimientos almacenados, datos reales, constraints y valores, se deben restaurar en SQL Server y consultar sus metadatos.
11. **Paquete de reconciliación:** se identifican controles de estructura, dimensiones, medidas, costos históricos y reconciliación OLTP/STG/DW; inspeccionar los procedimientos almacenados asociados para conocer exactamente qué comprueban.
12. **Privacidad:** la dimensión empleado incluye datos personales (documento, correo, teléfono, fecha de nacimiento). El BI debe aplicar minimización de datos y permisos; los dashboards ejecutivos normalmente no necesitan exponer identificadores personales directos.

---

## 8. Propuesta de trabajo para construir el BI

El equipo debe avanzar sobre el DW existente y evitar rediseñarlo sin una necesidad comprobada.

### Fase A. Auditoría técnica del DW

1. Restaurar los respaldos en un entorno SQL Server de trabajo.
2. Obtener el inventario de esquemas, tablas, columnas, tipos de datos, claves y relaciones.
3. Revisar vistas, procedimientos almacenados, funciones y triggers.
4. Consultar conteos y rangos de fechas de cada dimensión y del hecho.
5. Comprobar integridad referencial y claves desconocidas.
6. Verificar el cálculo y la carga de `CostoTotalRotacion`.
7. Investigar nivel de instrucción y costos de retención.
8. Confirmar el comportamiento histórico de dimensiones y del hecho.

### Fase B. Definición funcional de indicadores

Para cada KPI documentar:
- Nombre.
- Pregunta de negocio.
- Definición.
- Fórmula.
- Numerador y denominador.
- Grano.
- Periodo de análisis.
- Dimensiones de segmentación.
- Fuente de datos.
- Tratamiento de NULL/0.
- Limitaciones.
- Responsable de validar la definición.

### Fase C. Capa semántica y modelo BI

- Usar `DW.HechoRotacion` como tabla central de eventos.
- Relacionarla con las dimensiones mediante claves sustitutas.
- Configurar relaciones de uno a muchos desde dimensiones hacia el hecho, cuando la estructura física lo permita.
- Marcar `DimTiempo` como tabla de fechas si la herramienta BI lo requiere.
- Crear medidas explícitas para altas, bajas, balance, costos y tasas.
- Evitar relaciones ambiguas y medidas que sumen atributos no aditivos, como salarios mensuales.
- Mantener nombres de medidas comprensibles para el usuario final.

### Fase D. Diseño de paneles

Una organización posible:

**Página 1 — Resumen ejecutivo**
- Altas.
- Bajas.
- Balance neto.
- Tasa de rotación, cuando se haya definido el denominador.
- Costo de rotación respaldado.
- Tendencia temporal.

**Página 2 — Análisis de turnos**
- Bajas por turno/horario.
- Altas y bajas comparadas.
- Tasa por turno si existe dotación promedio.
- Filtros por sede y periodo.

**Página 3 — Perfil del personal**
- Distribución por nivel de instrucción, solo si el atributo está disponible.
- Distribución por cargo, sede y turno.
- Estado laboral, respetando la naturaleza histórica de los datos.

**Página 4 — Costos**
- Costo de desvinculación.
- Costo total de rotación, solo después de verificar su definición.
- Desglose por motivo, sede, cargo, turno y periodo.
- Costo de retención, solo si se dispone de datos y definición de negocio.

---

## 9. Consultas de auditoría sugeridas

Las siguientes consultas son ejemplos para ejecutar **después de restaurar el DW** y confirmar los nombres y tipos de columnas. No sustituyen la auditoría del esquema.

```sql
-- Inventario de tablas de usuario
SELECT
    s.name AS Esquema,
    t.name AS Tabla
FROM sys.tables t
INNER JOIN sys.schemas s
    ON t.schema_id = s.schema_id
ORDER BY s.name, t.name;

-- Columnas de las tablas dimensionales y de hechos
SELECT
    s.name AS Esquema,
    t.name AS Tabla,
    c.column_id,
    c.name AS Columna,
    ty.name AS TipoDato,
    c.max_length,
    c.is_nullable
FROM sys.tables t
INNER JOIN sys.schemas s
    ON t.schema_id = s.schema_id
INNER JOIN sys.columns c
    ON c.object_id = t.object_id
INNER JOIN sys.types ty
    ON ty.user_type_id = c.user_type_id
WHERE s.name IN ('DW', 'STG')
ORDER BY s.name, t.name, c.column_id;

-- Conteo de eventos por tipo
SELECT
    TipoEvento,
    SUM(CantidadAltas) AS Altas,
    SUM(CantidadBajas) AS Bajas,
    COUNT(*) AS Eventos
FROM DW.HechoRotacion
GROUP BY TipoEvento;

-- Movimientos por periodo (ajustar el campo de periodo a la estructura real de DimTiempo)
SELECT
    F.Fecha,
    SUM(H.CantidadAltas) AS Altas,
    SUM(H.CantidadBajas) AS Bajas
FROM DW.HechoRotacion H
INNER JOIN DW.DimTiempo F
    ON H.IdFecha = F.IdFecha
GROUP BY F.Fecha
ORDER BY F.Fecha;

-- Costo de desvinculación por motivo
SELECT
    M.NombreMotivo,
    SUM(H.CostoDesvinculacion) AS CostoDesvinculacion,
    SUM(H.CantidadBajas) AS Bajas
FROM DW.HechoRotacion H
LEFT JOIN DW.DimMotivoSalida M
    ON H.IdMotivoSalidaSK = M.IdMotivoSalidaSK
WHERE H.TipoEvento = 'BAJA'
GROUP BY M.NombreMotivo
ORDER BY CostoDesvinculacion DESC;
```

Estas consultas son un punto de partida. Antes de usarlas en producción, verificar nombres de columnas, tipos, semántica de fechas, claves desconocidas y duplicidades.

---

## 10. Instrucciones para la IA que continúe el proyecto

Actúa como arquitecto de Business Intelligence, especialista en Data Warehousing, SQL Server, SSIS y análisis de recursos humanos.

Debes trabajar sobre el proyecto descrito en este documento y respetar estas reglas:

1. **El Data Warehouse ya está desarrollado en una primera versión.** No propongas rehacerlo desde cero. Primero comprende y audita lo existente.
2. Distingue siempre entre:
   - Lo que el código y el esquema demuestran.
   - Lo que es una inferencia razonable.
   - Lo que falta verificar.
   - Lo que sería una propuesta de mejora.
3. No inventes tablas, columnas, relaciones, valores, resultados ni reglas de negocio.
4. Si necesitas confirmar el esquema físico, solicita o inspecciona los respaldos restaurados y consulta SQL Server.
5. El objetivo final del BI es responder estas cinco preguntas:
   - ¿Cuál es la tasa de rotación y cuántas altas/bajas hay?
   - ¿Cuál es el turno con más rotación?
   - ¿Cuál es el nivel de instrucción del personal?
   - ¿Cuál es el costo por rotación del personal?
   - ¿Cuál es el costo de retención?
6. No calcules una tasa porcentual sin definir su fórmula y denominador. Diferencia volumen de bajas de tasa de rotación.
7. No afirmes que el nivel de instrucción está disponible: el SELECT de empleados revisado no lo incluye. Verifica el OLTP y el DW.
8. No afirmes que el costo de retención está disponible: primero identifica su fuente y define qué conceptos lo componen.
9. No equipares automáticamente `CostoDesvinculacion` con el costo total de rotación. Investiga `CostoTotalRotacion` y evita doble contabilización.
10. Considera que la tabla de hechos tiene grano de evento (`ALTA` o `BAJA`), no una fila por empleado.
11. Para analizar turno, diferencia `NombreTurno` de `NombreHorario` y usa la asignación válida en la fecha del evento.
12. Diseña medidas que respeten el grano y la aditividad de los campos. No sumes salarios mensuales como si fueran costos de evento.
13. Antes de diseñar visualizaciones, entrega un diagnóstico de disponibilidad de datos para cada KPI: disponible, parcialmente disponible o no disponible, justificando cada clasificación.
14. Cuando propongas cambios al DW o ETL, explica por qué son necesarios, qué objetos afectan y qué impacto tienen sobre los procesos existentes.
15. Trabaja paso a paso, documenta supuestos y pide confirmación cuando una definición de negocio no pueda deducirse de los datos.

### Resultado esperado de la siguiente etapa

Una solución BI coherente con el Data Warehouse existente, con indicadores correctamente definidos, trazabilidad hasta las fuentes y visualizaciones que respondan las preguntas de negocio sin ocultar las limitaciones de los datos.

---

## 11. Resumen ejecutivo para orientar a la IA

- **Dominio:** recursos humanos de un Call Center.
- **Problema analítico:** rotación de personal.
- **Origen identificado:** `BD_CallCenter_Rotacion`.
- **Data Warehouse identificado:** `DWT4_Rotacion`.
- **Tecnología ETL:** SQL Server Integration Services (SSIS).
- **Área de staging:** esquema `STG`.
- **Área dimensional:** esquema `DW`.
- **Hecho central:** `DW.HechoRotacion`.
- **Dimensiones identificadas:** Tiempo, Empleado, Cargo, Sede, Turno y Motivo de salida.
- **Grano del hecho:** un registro por evento de alta o baja.
- **Medidas evidenciadas:** CantidadAltas, CantidadBajas, AntiguedadDias, SalarioMensual y CostoDesvinculacion. `CostoTotalRotacion` aparece en validaciones y requiere inspección adicional.
- **KPI con base directa parcial:** altas, bajas, costo de desvinculación y análisis por turno.
- **KPI que requiere verificar o ampliar datos:** tasa de rotación (denominador de dotación promedio), nivel de instrucción y costo de retención.
- **Objetivo inmediato:** auditar el DW y determinar la disponibilidad real de datos antes de construir el modelo semántico y los dashboards.

**Fin del documento.**
